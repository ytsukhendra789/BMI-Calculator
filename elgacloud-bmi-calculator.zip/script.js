function calculateBMI() {
    const weight = parseFloat(document.getElementById('weight').value);
    const height = parseFloat(document.getElementById('height').value) / 100; // Convert cm to meters
    const age = parseInt(document.getElementById('age').value);

    if (isNaN(weight) || isNaN(height) || height === 0 || isNaN(age) || age <= 0) {
        alert('Please enter valid numbers for weight, height, and age.');
        return;
    }
    
    const bmi = weight / (height * height);
    const bmiValue = document.getElementById('bmiValue');
    const bmiCategory = document.getElementById('bmiCategory');
    const suggestionsContent = document.getElementById('suggestionsContent');
    
    bmiValue.textContent = `Your BMI: ${bmi.toFixed(2)} (Age: ${age} years)`;
    
    let category = '';
    let suggestions = '';
    
    // Age-specific weight and height validation
    if (age < 1) {
        if (weight < 7 || weight > 11 || height < 60 || height > 76) {
            category = 'Unrealistic';
            suggestions = `
                <h3>For Infants (0-1 year):</h3>
                <ul>
                    <li><strong>Weight and Height:</strong> Ensure the values are within the normal range: Weight 7-11 kg, Height 60-76 cm.</li>
                </ul>
            `;
        } else {
            category = 'Normal weight';
            suggestions = `
                <h3>For Infants (0-1 year, Normal weight):</h3>
                <ul>
                    <li><strong>Maintain Healthy Growth:</strong> Continue regular check-ups with a pediatrician.</li>
                </ul>
            `;
        }
    } else if (age >= 1 && age <= 5) {
        if (weight < 10 || weight > 18 || height < 75 || height > 110) {
            category = 'Unrealistic';
            suggestions = `
                <h3>For Young Children (1-5 years):</h3>
                <ul>
                    <li><strong>Weight and Height:</strong> Ensure the values are within the normal range: Weight 10-18 kg, Height 75-110 cm.</li>
                </ul>
            `;
        } else {
            category = 'Normal weight';
            suggestions = `
                <h3>For Young Children (1-5 years, Normal weight):</h3>
                <ul>
                    <li><strong>Promote Healthy Growth:</strong> Ensure a balanced diet and regular physical activity.</li>
                </ul>
            `;
        }
    } else if (age >= 6 && age <= 12) {
        if (weight < 20 || weight > 40 || height < 110 || height > 150) {
            category = 'Unrealistic';
            suggestions = `
                <h3>For Children (6-12 years):</h3>
                <ul>
                    <li><strong>Weight and Height:</strong> Ensure the values are within the normal range: Weight 20-40 kg, Height 110-150 cm.</li>
                </ul>
            `;
        } else {
            category = 'Normal weight';
            suggestions = `
                <h3>For Children (6-12 years, Normal weight):</h3>
                <ul>
                    <li><strong>Healthy Lifestyle:</strong> Encourage a balanced diet and physical activity.</li>
                </ul>
            `;
        }
    } else if (age >= 13 && age <= 19) {
        if (weight < 40 || weight > 70 || height < 150 || height > 180) {
            category = 'Unrealistic';
            suggestions = `
                <h3>For Teens (13-19 years):</h3>
                <ul>
                    <li><strong>Weight and Height:</strong> Ensure the values are within the normal range: Weight 40-70 kg, Height 150-180 cm.</li>
                </ul>
            `;
        } else if (bmi < 18.5) {
            category = 'Underweight';
            suggestions = `
                <h3>For Teens (13-19 years, Underweight):</h3>
                <ul>
                    <li><strong>Increase Caloric Intake:</strong> Focus on a balanced diet with calorie-dense foods.</li>
                    <li><strong>Strength Training:</strong> Engage in resistance exercises to build muscle.</li>
                </ul>
            `;
        } else if (bmi >= 18.5 && bmi < 24.9) {
            category = 'Normal weight';
            suggestions = `
                <h3>For Teens (13-19 years, Normal weight):</h3>
                <ul>
                    <li><strong>Maintain Healthy Weight:</strong> Continue a balanced diet and regular physical activity.</li>
                </ul>
            `;
        } else {
            category = 'Overweight';
            suggestions = `
                <h3>For Teens (13-19 years, Overweight):</h3>
                <ul>
                    <li><strong>Monitor Caloric Intake:</strong> Reduce calorie consumption and focus on a balanced diet.</li>
                    <li><strong>Increase Physical Activity:</strong> Engage in regular exercise and sports.</li>
                </ul>
            `;
        }
    } else if (age >= 20) {
        if (bmi < 18.5) {
            category = 'Underweight';
            suggestions = `
                <h3>For Adults (20+ years, Underweight):</h3>
                <ul>
                    <li><strong>Increase Nutritional Intake:</strong> Add calorie-dense and nutrient-rich foods to your diet.</li>
                     <li><strong>Recommended Foods: :</strong>Include fruits like bananas, avocados, mangoes, and dry fruits like almonds, walnuts, and dates. These are high in healthy fats and calories.</li>
                      <li><strong>Daily Calorie Intake:</strong>Aim for a calorie surplus of about 500-700 calories per day to gain weight gradually. It is recommended to consult with a healthcare provider for personalized advice.</li>
                    <li><strong>Regular Exercise:</strong> Include strength training to build muscle mass.</li>
                    <li><strong>Consult a Healthcare Provider:</strong> Seek personalized advice for weight management.</li>
                </ul>
            `;
        } else if (bmi >= 18.5 && bmi < 24.9) {
            category = 'Normal weight';
            suggestions = `
                <h3>For Adults (20+ years, Normal weight):</h3>
                <ul>
                    <li><strong>Maintain Healthy Lifestyle:</strong> Continue with a balanced diet and regular exercise.</li>
                </ul>
            `;
        } else if (bmi >= 25 && bmi < 29.9) {
            category = 'Overweight';
            suggestions = `
                <h3>For Adults (20+ years, Overweight):</h3>
                <ul>
                    <li><strong>Reduce Caloric Intake:</strong> Monitor your diet and focus on healthy eating.</li>
                    <li><strong>Increase Physical Activity:</strong> Engage in regular aerobic and strength-training exercises.</li>
                </ul>
            `;
        } else {
            category = 'Obesity';
            suggestions = `
                <h3>For Adults (20+ years, Obesity):</h3>
                <ul>
                    <li><strong>Adopt a Healthy Diet:</strong> Focus on nutrient-rich foods and reduce processed food intake.</li>
                    <li><strong>Consult Healthcare Provider:</strong> Get personalized weight management and health advice.</li>
                </ul>
            `;
        }
    }
    
    bmiCategory.textContent = `Category: ${category}`;
    suggestionsContent.innerHTML = suggestions;

    // Scroll to the top of the page to ensure the user can see the results
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}
