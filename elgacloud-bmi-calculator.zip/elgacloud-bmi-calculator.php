<?php
/**
 * Plugin Name: ElgaCloud BMI Calculator
 * Description: A BMI calculator plugin by ElgaCloud that provides BMI calculations and suggestions.
 * Version: 1.0
 * Author: ElgaCloud
 * Author URI: https://elgacloud.com/
 * License: GPL2
 */

// Enqueue the plugin's CSS and JavaScript files
function elgacloud_bmi_enqueue_scripts() {
    wp_enqueue_style('elgacloud-bmi-style', plugins_url('styles.css', __FILE__));
    wp_enqueue_script('elgacloud-bmi-script', plugins_url('script.js', __FILE__), array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'elgacloud_bmi_enqueue_scripts');

// Register the shortcode for the BMI Calculator
function elgacloud_bmi_shortcode() {
    ob_start();
    ?>
    <div class="elgacloud-bmi-container">
        <h1>BMI Calculator</h1>
        <form id="bmiForm">
            <label for="weight">Weight (kg):</label>
            <input type="number" id="weight" name="weight" required>
            <label for="height">Height (cm):</label>
            <input type="number" id="height" name="height" required>
            <label for="age">Age (years):</label>
            <input type="number" id="age" name="age" required>
            <button type="button" onclick="calculateBMI()">Calculate BMI</button>
        </form>
        <div id="result">
            <p id="bmiValue"></p>
            <p id="bmiCategory"></p>
        </div>
        <div id="bmiExplanation">
            <h2>What is BMI?</h2>
            <p>
                Body Mass Index (BMI) is a measurement that uses your height and weight to estimate whether you are underweight, normal weight, overweight, or obese.
                <br><br>
                <strong>Categories:</strong>
                <ul>
                    <li>Underweight: BMI less than 18.5</li>
                    <li>Normal weight: BMI between 18.5 and 24.9</li>
                    <li>Overweight: BMI between 25 and 29.9</li>
                    <li>Obesity: BMI 30 or greater</li>
                </ul>
                While BMI is a useful tool, it does not measure body fat directly and may not be accurate for everyone, especially athletes or older adults.
            </p>
        </div>
        <div id="suggestions">
            <h2>Suggestions</h2>
            <div id="suggestionsContent"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('elgacloud_bmi_calculator', 'elgacloud_bmi_shortcode');

// Add the plugin menu to the WordPress admin dashboard
function elgacloud_bmi_add_admin_menu() {
    add_menu_page(
        'ElgaCloud BMI Calculator',
        'ElgaCloud BMI Calculator',
        'manage_options',
        'elgacloud-bmi-calculator',
        'elgacloud_bmi_admin_page',
        'dashicons-calculator',
        6
    );
}
add_action('admin_menu', 'elgacloud_bmi_add_admin_menu');

function elgacloud_bmi_admin_page() {
    echo '<div class="wrap"><h1>ElgaCloud BMI Calculator Plugin</h1>';
    echo '<p>Welcome to the ElgaCloud BMI Calculator plugin. Use the shortcode <strong><span style="color: #007bff;">[elgacloud_bmi_calculator]</span></strong> to display the BMI calculator on any page or post.</p>';
    echo '<p>If you want to buy Domain and Hosting at an affordable price, visit <a href="https://elgacloud.com/" target="_blank" style="color: #007bff;">ElgaCloud.com</a></p>';
    echo '</div>';
}
